function [trough_timestamps] = detect_trough(ana_data,fq) 
% This function was written in Matlab Version 7.10.0.499(R2010a) 
% Function containing code to perform trough detection on local field potential (LFP) recordings.
% input1: ana_data (LFP data for analysis)
% input2: fq  (the original sampling rate of LFP)
% output: trough_timestamps (detected trough (ms))
% Written by Jenq-Wei Yang (2017)

reduce_p=fq/1000;
ana_data=ana_data(:,1:reduce_p:end);% downsampling to 1000Hz
fq=fq/reduce_p;%downsampling to 1000Hz


%------filter data1(4-30Hz)------
low_cut=4;
high_cut=30;
n = 3; Wn = [low_cut high_cut]/(0.5*fq);
[b,a] = butter(n,Wn);
filter_ana1=(filtfilt(b,a,ana_data));



%------filter data2(30-100Hz)------
low_cut2=30;
high_cut2=100;
n = 3; Wn = [low_cut2 high_cut2]/(0.5*fq);
[b,a] = butter(n,Wn);
filter_ana2=(filtfilt(b,a,ana_data));

%------plot raw data------
points=length(ana_data);
figure(2)
clf
axes('position',[.1  .65 .8  .3])
plot(ana_data)
xlim([0 points])
axis off
fp_yscale=round(abs(min(ana_data))/100)*100;
y_scale=-1*fp_yscale:10:0;
line(points,y_scale,'Color','red')
text(1.01*points,-0.5*fp_yscale, [ num2str(fp_yscale) ' uV'],'FontSize',8);
text(0,0.2*fp_yscale, 'original trace','FontSize',12);    

%%%%%%%%%% detect through for filter_ana1(4-30Hz) %%%%%%%%%%%%%%%%%%%
axes('position',[.1  .4  .8  .3])
plot(filter_ana1)
xlim([0 points])
yscale_filter1=round(abs(min(filter_ana1))/100)*100;
y_scale=-1*yscale_filter1:10:0;
line(points,y_scale,'Color','red')
text(1.01*points,-0.5*yscale_filter1, [ num2str(yscale_filter1) ' uV'],'FontSize',8);
text(0,0.2*yscale_filter1, ' filter trace (4 to 30 Hz)' ,'FontSize',12);
axis off

[c]=ginput(2); 
Std_value=std(filter_ana1(round(c(1)):round(c(2))));
Threshold1=-8*Std_value;
hold on
x_line=0:10:points;
plot(x_line,Threshold1,'Color','red')


a_p=find(filter_ana1<Threshold1);
if length(a_p)>1
    b_p(1)=a_p(1);
    j=2;
    for i=2:length(a_p)
        if a_p(i)-a_p(i-1)>10
            b_p(j)=a_p(i);
            j=j+1;
        end
    end
    %%% alingment
    b_L=find(b_p<length(filter_ana1)-31);

    for i=1:length(b_L)
        pp=b_p(i);
        sweep=filter_ana1(1,(pp:(pp+30)));
        min_p=min(sweep);
        aa=find(filter_ana1(1,(pp):(pp+30))==min_p(1));
        c_p(i)=pp+aa-1;  
    end
   
    %trough time_stamp
    j=1;
    a_L=find(c_p<length(filter_ana1)-31);
    time_stamp=zeros(1,(length(a_L)-1));
    for i=1:length(a_L)    
        time_stamp(j)=c_p(i)/fq*1000;% ms
        j=j+1;  
    end
    time_stamp=time_stamp';
    time_stamp=round(time_stamp);
else
    time_stamp=[];  
end    

hold on
plot(time_stamp,filter_ana1(time_stamp),'g+')

%%%%%%%%%% detect through for filter_ana2 (30-100Hz)%%%%%%%%%%%%%%%%%%%
axes('position',[.1  .1  .8  .3])
plot(filter_ana2)
xlim([0 points])
yscale_filter2=round(abs(min(filter_ana2))/100)*100;
y_scale=-1*yscale_filter2:10:0;
line(points,y_scale,'Color','red')
text(1.01*points,-0.5*yscale_filter2, [ num2str(yscale_filter2) ' uV'],'FontSize',8);
text(0,0.2*yscale_filter2, ' filter trace (30 to 100 Hz)' ,'FontSize',12);
axis off

[c]=ginput(2);
Std_value2=std(filter_ana2(round(c(1)):round(c(2))));
Threshold2=-8*Std_value2;
hold on
x_line=0:10:points;
plot(x_line,Threshold2,'Color','red')


a_p=find(filter_ana2<Threshold2);
if length(a_p)>1
    b_p(1)=a_p(1);
    j=2;
    for i=2:length(a_p)
        if a_p(i)-a_p(i-1)>3
            b_p(j)=a_p(i);
            j=j+1;
        end
    end

    %%% alingment
    b_L=find(b_p<length(filter_ana2)-6);

    for i=1:length(b_L)
        pp=b_p(i);
        sweep=filter_ana2(1,(pp:(pp+5)));
        min_p=min(sweep);
        aa=find(filter_ana2(1,(pp):(pp+5))==min_p(1));
        c_p(i)=pp+aa-1;
    end
   
    %trough time_stamp 
    j=1;
    a_L=find(c_p<length(filter_ana2)-6);
    time_stamp2=zeros(1,(length(a_L)-1));
    for i=1:length(a_L)    
        time_stamp2(j)=c_p(i)/fq*1000;% ms
        j=j+1;  
    end
    time_stamp2=time_stamp2';
    time_stamp2=round(time_stamp2);
else
    time_stamp2=[];  
end    

hold on
plot(time_stamp2,filter_ana2(time_stamp2),'g+')

%%%Merge detected troughs from 4-30Hz and 30-100Hz filtering traces
%%%Duplication in detection of trough in both filtered data sets were prevented by exclusion of troughs occurring within 8 ms of each other 
T_L=length(time_stamp)+length(time_stamp2);
total_time_stamp=zeros(1,T_L);
total_time_stamp(1,1:length(time_stamp))=time_stamp';
total_time_stamp(1,(length(time_stamp)+1):T_L)=time_stamp2';
total_time_stamp=sort(total_time_stamp);
f=diff(total_time_stamp);
d_p=find(f<8);
d_p=d_p+1;
total_time_stamp(d_p)=0;
d_p2=find(total_time_stamp>0);
total_time_stamp=total_time_stamp(d_p2); 

axes('position',[.1  .65 .8  .3])
plot(ana_data)
xlim([0 points])
axis off
fp_yscale=round(abs(min(ana_data))/100)*100;
y_scale=-1*fp_yscale:10:0;
line(points,y_scale,'Color','red')
text(1.01*points,-0.5*fp_yscale, [ num2str(fp_yscale) ' uV'],'FontSize',8);
text(0,0.2*fp_yscale, 'original trace','FontSize',12);  

hold on
plot(total_time_stamp,ana_data(total_time_stamp),'r+')

trough_timestamps=total_time_stamp;
