function [F1,mean_fft] = mean_FFT(ana_data,fq,unit) 
% This function was written in Matlab Version 7.10.0.499(R2010a) 
%Function containing code to calculate the mean FFT of local field potential (LFP) recordings.
% input1: ana_data (LFP data for analysis)
% input2: fq  (the original sampling rate of LFP)
% input3: unit (define the time of segment)
% output: F1 (frequency scale: a frequency resolution of 0.2 Hz)
% output: mean_fft (FFT power corresponding to F1)
% Written by Jenq-Wei Yang (2017)

Total_time=length(ana_data)/fq;
run_num=fix(Total_time/unit);

reduce_p=fq/1000;
ana_data=ana_data(:,1:reduce_p:end);% downsampling to 1000Hz
fq=fq/reduce_p;%downsampling to 1000Hz

all_pxx=zeros(run_num,unit*fq);
for m=1:run_num
    segment_data=ana_data((1+unit*fq*(m-1)):unit*fq*m);
    points=length(segment_data);
    X1=abs(fft(segment_data,points));
    Pxx1=X1.* conj(X1) /points;
    all_pxx(m,:)=Pxx1;
end
F1=fq*(0:points-1)/points; 
F1=F1(1:2500);
mean_fft=mean(all_pxx,1);
mean_fft=mean_fft(1:2500);  

figure(1)
clf
plot(F1(1:401),mean_fft(1:401))
title('mean-FFT')
xlabel('Frenquecy(Hz)')
ylabel('Spectral power')
